class Main {
    public static void main(String[] args){
       //Arreglo del tipo Figura y guarda objetos de la subclase
        Figura[] figuras = {
                new Circulo("Verde",true,9),
                new Circulo("Rojo",false,3),

                new Rectangulo("Azul",true,5.2,4.2),
                new Rectangulo("Amarillo",false,1.2,8.9),

                new TrianguloRectangulo("Violeta",true,5.2,3.1),
                new TrianguloRectangulo("Café",false,1.0,2.5)
        };

        for (Figura f: figuras){
            f.describir();
        }
    }
}
