public class Circulo extends Figura {
    private double radio;

    public Circulo(String color,boolean relleno,double radio){
        super(color,relleno);
        this.radio = radio;
    }

    @Override
    public double calcularArea(){
        return Math.PI * radio * radio;
    }

    @Override
    public double calcularPerimetro(){
        return 2 * Math.PI * radio;
    }
}
