public class Auto extends Vehiculo implements Electrico{
    private int bateria;

    public Auto(String marca,String modelo,double velocidadMaxima,int bateria){
        super(marca, modelo, velocidadMaxima);
        this.bateria = bateria;
    }

    @Override
    public void describir(){
        super.describir();
        System.out.println("Bateria: " + bateria + "%");
    }

    @Override
    public void cargarBateria(int porcentaje){
        bateria += porcentaje;
        if (bateria > 100){
            bateria = 100;
        }
    }

    @Override
    public int autonomiaKm(){
        return bateria *2;
    }
}
