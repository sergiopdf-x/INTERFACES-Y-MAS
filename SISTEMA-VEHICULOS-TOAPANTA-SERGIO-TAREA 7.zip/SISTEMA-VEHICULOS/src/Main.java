class Main{
    public static void main(String[] args){
        Auto a = new Auto("Tesla","Model 3",250,82);
        Moto m = new Moto("Yamaha","R6",220,500);
        Camion c = new Camion("Volvo","FH16",150,10);

        Vehiculo[] vehiculos = {a,m,c};

        for (Vehiculo v : vehiculos){
            v.describir();
            System.out.println();
        }

        a.cargarBateria(20);
        System.out.println("Autonomia del auto: " + a.autonomiaKm() + "km");
    }
}
