public class Camion extends Vehiculo{
    private double capacidadCarga;

    public Camion(String marca,String modelo,double velocidadMaxima,double capacidadCarga){
        super(marca, modelo, velocidadMaxima);
        this.capacidadCarga = capacidadCarga;
    }

    @Override
    public void describir(){
        super.describir();
        System.out.println("Capacidad carga: " + capacidadCarga);
    }
}
