public class Moto extends Vehiculo{
    private int cilindraje;

    public Moto(String modelo,String marca,double velocidadMaxima,int cilindraje){
        super(marca, modelo, velocidadMaxima);
        this.cilindraje = cilindraje;
    }

    @Override
    public void describir(){
        super.describir();
        System.out.println("Cilindraje: " + cilindraje);
    }
}
