class Main {
    public static void main(String[] args){
        Empleado[] empleados = {
                new EmpleadoPorHora("Belen",101,5,4.2),
                new EmpleadoPorHora("Angie",102,4,3.1),

                new EmpleadoFijo("Sergio",103,7,900),
                new EmpleadoFijo("Amparo",104,40,1200),

                new EmpleadoComision("Pedro",105,40,500,10,3000),
                new EmpleadoComision("Sofia",106,50,750,5,200)
        };

        for (Empleado e: empleados){
            e.mostrarInfo();

            if (e instanceof Bonificable b){
                System.out.println("Bono: " + b.calcularBono());
            }
        }
    }
}
